<?php

$username=$_post['username'];
$password=$_post['password'];

if($username=="ankush" and $password=="ankush123")
{
    //echo"valid";
    header("location:products.html");
}
else
{
	//echo"wrong";
	header("location:products.html");
}

?>